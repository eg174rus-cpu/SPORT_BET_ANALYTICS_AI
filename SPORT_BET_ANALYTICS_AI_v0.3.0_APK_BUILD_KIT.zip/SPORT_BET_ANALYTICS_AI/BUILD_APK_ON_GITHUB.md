# Как получить APK SPORT BET ANALYTICS AI (v0.3.0)

В этом архиве добавлен GitHub Actions workflow для облачной сборки APK. APK пока не собран локально: в текущей среде нет Android SDK/Gradle, и загрузка SDK недоступна.

## Сборка в GitHub
1. Создайте GitHub репозиторий (можно Private).
2. Загрузите/распакуйте содержимое этой папки проекта в репозиторий, сохранив папку `.github/workflows`.
3. Откройте вкладку **Actions** в репозитории.
4. Выберите **Build SPORT BET ANALYTICS AI APK** слева.
5. Нажмите **Run workflow** → **Run workflow**.
6. Дождитесь зелёного статуса завершения.
7. Откройте завершённый запуск и скачайте Artifact **SPORT_BET_ANALYTICS_AI-debug-apk**.
8. Распакуйте скачанный Artifact — внутри будет `app-debug.apk`. Перенесите APK на Samsung Galaxy S24 и откройте его для установки. Android может запросить разрешение «Установка неизвестных приложений» для браузера/файлового менеджера.

## Сведения о сборке
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17
- compileSdk 35
- minSdk 26 (Android 8.0+)
- versionName 0.3.0 / versionCode 3

Debug APK подписывается стандартным debug-ключом, созданным средой сборки. Это тестовая установка, не релиз в Google Play.
