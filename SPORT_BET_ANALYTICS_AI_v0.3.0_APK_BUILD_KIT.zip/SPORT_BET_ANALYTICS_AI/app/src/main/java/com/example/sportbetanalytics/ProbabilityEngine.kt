package com.example.sportbetanalytics

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

data class MarketAnalysis(
    val impliedProbability: Double,
    val fairOdds: Double,
    val expectedValue: Double,
    val edge: Double
)

object ProbabilityEngine {
    fun impliedProbability(decimalOdds: Double): Double? =
        if (decimalOdds > 1.0 && decimalOdds.isFinite()) 1.0 / decimalOdds else null

    /** Removes bookmaker margin proportionally from a complete 1X2 odds set. */
    fun fairThreeWay(home: Double, draw: Double, away: Double): List<Double>? {
        val odds = listOf(home, draw, away)
        if (odds.any { it <= 1.0 || !it.isFinite() }) return null
        val raw = odds.map { 1.0 / it }
        val total = raw.sum()
        return raw.map { it / total }
    }

    fun analyze(probability: Double, decimalOdds: Double, stake: Double): MarketAnalysis? {
        if (probability !in 0.0..1.0 || decimalOdds <= 1.0 || stake < 0.0) return null
        val fair = if (probability > 0.0) 1.0 / probability else Double.POSITIVE_INFINITY
        val ev = stake * (probability * (decimalOdds - 1.0) - (1.0 - probability))
        return MarketAnalysis(1.0 / decimalOdds, fair, ev, probability - 1.0 / decimalOdds)
    }

    fun poisson(lambda: Double, goals: Int): Double {
        if (lambda < 0.0 || goals < 0) return 0.0
        if (lambda == 0.0) return if (goals == 0) 1.0 else 0.0
        var factorial = 1.0
        for (i in 1..goals) factorial *= i
        return exp(-lambda) * lambda.pow(goals) / factorial
    }

    data class FootballModel(
        val homeWin: Double,
        val draw: Double,
        val awayWin: Double,
        val over25: Double,
        val under25: Double,
        val bothTeamsScore: Double,
        val scoreMatrix: List<Triple<Int, Int, Double>>
    )

    /** Independent Poisson baseline; requires user-supplied expected goals. */
    fun football(homeExpectedGoals: Double, awayExpectedGoals: Double, maxGoals: Int = 10): FootballModel {
        require(homeExpectedGoals >= 0 && awayExpectedGoals >= 0 && maxGoals in 5..15)
        var home = 0.0; var draw = 0.0; var away = 0.0
        var over = 0.0; var btts = 0.0
        val scores = mutableListOf<Triple<Int, Int, Double>>()
        for (h in 0..maxGoals) for (a in 0..maxGoals) {
            val p = poisson(homeExpectedGoals, h) * poisson(awayExpectedGoals, a)
            scores += Triple(h, a, p)
            when { h > a -> home += p; h == a -> draw += p; else -> away += p }
            if (h + a >= 3) over += p
            if (h > 0 && a > 0) btts += p
        }
        return FootballModel(home, draw, away, over, 1.0 - over, btts,
            scores.sortedByDescending { it.third }.take(10))
    }
}
