package com.example.sportbetanalytics

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale

private fun pct(v: Double) = String.format(Locale.US, "%.1f%%", v * 100.0)
private fun num(v: Double) = if (v.isFinite()) String.format(Locale.US, "%.2f", v) else "—"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SportBetApp() }
    }
}

@Composable
fun SportBetApp() {
    var sport by remember { mutableStateOf("Футбол") }
    var homeLambda by remember { mutableStateOf("1.45") }
    var awayLambda by remember { mutableStateOf("0.95") }
    var odds by remember { mutableStateOf("1.90") }
    var probability by remember { mutableStateOf("0.60") }
    var stake by remember { mutableStateOf("10") }
    var marketHomeOdds by remember { mutableStateOf("2.10") }
    var marketDrawOdds by remember { mutableStateOf("3.30") }
    var marketAwayOdds by remember { mutableStateOf("3.60") }
    // Match Analyzer inputs: home team's home averages and away team's away averages.
    var homeScoredAvg by remember { mutableStateOf("1.60") }
    var homeConcededAvg by remember { mutableStateOf("0.90") }
    var awayScoredAvg by remember { mutableStateOf("1.20") }
    var awayConcededAvg by remember { mutableStateOf("1.40") }
    val matchLambda = remember(homeScoredAvg, homeConcededAvg, awayScoredAvg, awayConcededAvg) {
        val hs = homeScoredAvg.toDoubleOrNull(); val hc = homeConcededAvg.toDoubleOrNull()
        val asg = awayScoredAvg.toDoubleOrNull(); val ac = awayConcededAvg.toDoubleOrNull()
        if (listOf(hs, hc, asg, ac).all { it != null && it >= 0.0 }) {
            // Geometric mean of a team's attack and opponent's defensive concession average.
            Pair(kotlin.math.sqrt(hs!! * ac!!), kotlin.math.sqrt(asg!! * hc!!))
        } else null
    }
    val matchModel = remember(matchLambda) {
        matchLambda?.let { runCatching { ProbabilityEngine.football(it.first, it.second) }.getOrNull() }
    }
    val marketFair = remember(marketHomeOdds, marketDrawOdds, marketAwayOdds) {
        val h = marketHomeOdds.toDoubleOrNull(); val d = marketDrawOdds.toDoubleOrNull(); val a = marketAwayOdds.toDoubleOrNull()
        if (h != null && d != null && a != null) ProbabilityEngine.fairThreeWay(h, d, a) else null
    }
    val marketOverround = remember(marketHomeOdds, marketDrawOdds, marketAwayOdds) {
        val h = marketHomeOdds.toDoubleOrNull(); val d = marketDrawOdds.toDoubleOrNull(); val a = marketAwayOdds.toDoubleOrNull()
        if (h != null && d != null && a != null && h > 1 && d > 1 && a > 1) (1.0/h + 1.0/d + 1.0/a - 1.0) else null
    }
    val model = remember(homeLambda, awayLambda) {
        val h = homeLambda.toDoubleOrNull()
        val a = awayLambda.toDoubleOrNull()
        if (h != null && a != null && h >= 0 && a >= 0)
            runCatching { ProbabilityEngine.football(h, a) }.getOrNull() else null
    }
    val analysis = remember(odds, probability, stake) {
        val o = odds.toDoubleOrNull(); val p = probability.toDoubleOrNull(); val s = stake.toDoubleOrNull()
        if (o != null && p != null && s != null) ProbabilityEngine.analyze(p, o, s) else null
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF63A5FF),
        background = androidx.compose.ui.graphics.Color(0xFF0B1220),
        surface = androidx.compose.ui.graphics.Color(0xFF152238)
    )) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("SPORT BET ANALYTICS AI", style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Математический анализ спортивных рынков", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("ВИД СПОРТА", fontWeight = FontWeight.Bold)
                        var expanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { expanded = true }) { Text(sport) }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                listOf("Футбол", "Баскетбол", "Теннис", "Хоккей", "Другой спорт").forEach {
                                    DropdownMenuItem(text = { Text(it) }, onClick = { sport = it; expanded = false })
                                }
                            }
                        }
                        Text("ФУТБОЛ · МОДЕЛЬ ОЖИДАЕМЫХ ГОЛОВ", fontWeight = FontWeight.Bold)
                        NumberField("Ожидаемые голы хозяев (λ)", homeLambda) { homeLambda = it }
                        NumberField("Ожидаемые голы гостей (λ)", awayLambda) { awayLambda = it }
                        if (sport == "Футбол" && model != null) {
                            Divider()
                            Text("Оценка модели", fontWeight = FontWeight.Bold)
                            ResultLine("Победа хозяев", pct(model.homeWin))
                            ResultLine("Ничья", pct(model.draw))
                            ResultLine("Победа гостей", pct(model.awayWin))
                            ResultLine("Тотал больше 2.5", pct(model.over25))
                            ResultLine("Тотал меньше 2.5", pct(model.under25))
                            ResultLine("Обе забьют — да", pct(model.bothTeamsScore))
                            Text("Наиболее вероятные счета", fontWeight = FontWeight.Bold)
                            model.scoreMatrix.take(5).forEach {
                                ResultLine("${it.first}:${it.second}", pct(it.third))
                            }
                        } else {
                            Text("Для выбранного вида спорта профиль модели пока не подключён. Футбольная модель использует вводимые ожидаемые голы.")
                        }
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("MATCH ANALYZER · СТАТИСТИЧЕСКИЕ СРЕДНИЕ", fontWeight = FontWeight.Bold)
                        Text("Введите средние голы за матч отдельно для домашней и выездной игры. Параметры λ рассчитываются геометрическим объединением атаки одной команды и оборонительных показателей соперника.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        NumberField("Хозяева: среднее забитых дома", homeScoredAvg) { homeScoredAvg = it }
                        NumberField("Хозяева: среднее пропущенных дома", homeConcededAvg) { homeConcededAvg = it }
                        NumberField("Гости: среднее забитых в гостях", awayScoredAvg) { awayScoredAvg = it }
                        NumberField("Гости: среднее пропущенных в гостях", awayConcededAvg) { awayConcededAvg = it }
                        if (matchLambda != null && matchModel != null) {
                            Divider()
                            Text("Расчётные параметры", fontWeight = FontWeight.Bold)
                            ResultLine("λ хозяев", num(matchLambda.first))
                            ResultLine("λ гостей", num(matchLambda.second))
                            Text("Вероятности по модели", fontWeight = FontWeight.Bold)
                            ResultLine("П1", pct(matchModel.homeWin))
                            ResultLine("X", pct(matchModel.draw))
                            ResultLine("П2", pct(matchModel.awayWin))
                            ResultLine("ТБ 2.5", pct(matchModel.over25))
                            ResultLine("ТМ 2.5", pct(matchModel.under25))
                            ResultLine("Обе забьют", pct(matchModel.bothTeamsScore))
                        } else Text("Введите неотрицательные числовые средние.")
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("АНАЛИЗ РЫНКА 1X2", fontWeight = FontWeight.Bold)
                        Text("Введите коэффициенты на победу хозяев, ничью и победу гостей. Маржа будет удалена пропорционально.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        NumberField("Победа хозяев — коэффициент", marketHomeOdds) { marketHomeOdds = it }
                        NumberField("Ничья — коэффициент", marketDrawOdds) { marketDrawOdds = it }
                        NumberField("Победа гостей — коэффициент", marketAwayOdds) { marketAwayOdds = it }
                        if (marketFair != null && marketOverround != null) {
                            Divider()
                            Text("Вероятности рынка без маржи", fontWeight = FontWeight.Bold)
                            ResultLine("Победа хозяев", pct(marketFair[0]))
                            ResultLine("Ничья", pct(marketFair[1]))
                            ResultLine("Победа гостей", pct(marketFair[2]))
                            ResultLine("Маржа / overround", pct(marketOverround))
                            Text("Fair odds (без маржи)", fontWeight = FontWeight.Bold)
                            ResultLine("Хозяева", num(1.0 / marketFair[0]))
                            ResultLine("Ничья", num(1.0 / marketFair[1]))
                            ResultLine("Гости", num(1.0 / marketFair[2]))
                        } else Text("Введите все три коэффициента, каждый должен быть больше 1.00.")
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("VALUE / EXPECTED VALUE", fontWeight = FontWeight.Bold)
                        NumberField("Ваша оценка вероятности (0–1)", probability) { probability = it }
                        NumberField("Десятичный коэффициент", odds) { odds = it }
                        NumberField("Размер ставки (условные единицы)", stake) { stake = it }
                        if (analysis != null) {
                            Divider()
                            ResultLine("Вероятность букмекера", pct(analysis.impliedProbability))
                            ResultLine("Справедливый коэффициент", num(analysis.fairOdds))
                            ResultLine("Преимущество модели", pct(analysis.edge))
                            ResultLine("Ожидаемый результат", num(analysis.expectedValue))
                            Text(
                                if (analysis.expectedValue > 0) "Положительное математическое ожидание при заданной вероятности."
                                else "Положительного математического ожидания по введённым данным нет.",
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else Text("Проверьте ввод: вероятность 0–1, коэффициент больше 1, ставка неотрицательная.")
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("ВАЖНО", fontWeight = FontWeight.Bold)
                        Text("Это офлайн-прототип расчётного ядра. Данные λ и вероятность вводятся вручную и не являются прогнозом реального матча. Автоматические спортивные ленты, live-коэффициенты, модели других видов спорта и синхронизация ещё не подключены. Историческая проверка и калибровка обязательны перед практическим использованием.")
                    }
                }
                Text("Версия 0.3.0 · Android 8.0+ · Galaxy S24", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text(label) },
        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}
@Composable
private fun ResultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
